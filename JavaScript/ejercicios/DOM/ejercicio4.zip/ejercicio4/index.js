//Crear una tabla que muestre un array de libros guardado en memoria. Requisitos:
//1.Usar estilos de Bootstrap 4. Se puede utilizar el CSS directamente desde el CDN.
//2.Crear un constructor de objeto Book con los siguientes atributos: ID, título, autor, ventas yprecio.
//3.Rellenar un array con 10 libros.
// 4.Para cada elemento del array, tendremos crear una nueva fila en la tabla con las columnas para todas
// las propiedades del objeto además de un botón para poder eliminar el libro.Se aconseja la creación de
// una función para actualizar la tabla (o el tbody) desde cero.
//5.Si el botón de eliminar es pulsado, borrará el libro del array y actualizará la tabla.
//6.Añadir un pequeño formulario después de la tabla para poder anexar un nuevo libro a nuestro array.
//Tras hacer submit, además de añadirlo, deberá actualizar la tabla y vaciar los inputs.
