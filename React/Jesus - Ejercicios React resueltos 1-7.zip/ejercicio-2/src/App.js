import Tienda from "./components/Tienda";

function App() {
  return <Tienda />;
}

export default App;
