import Tienda from "../components/Tienda";

function Ejercicio2() {
  return <Tienda />;
}

export default Ejercicio2;
