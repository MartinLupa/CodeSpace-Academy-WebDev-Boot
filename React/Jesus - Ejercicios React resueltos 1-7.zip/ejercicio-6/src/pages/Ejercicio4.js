import ToDoList from "../components/ToDoList";
import NewItem from "../components/NewItem";

function Ejercicio4() {
  return (
    <div>
      <NewItem />
      <ToDoList />
    </div>
  );
}

export default Ejercicio4;
