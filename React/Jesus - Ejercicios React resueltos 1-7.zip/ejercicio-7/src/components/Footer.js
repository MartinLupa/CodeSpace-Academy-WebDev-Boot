export default function Footer() {
    return (
        <footer className="bg-dark py-5">
            <h5 className="text-light text-center">CodeSpace Academy 2021 &copy;</h5>
        </footer>
    )
}
