export default function Error() {
    return (
        <div className="flex-grow-1">
            No existe esa página
        </div>
    )
}
